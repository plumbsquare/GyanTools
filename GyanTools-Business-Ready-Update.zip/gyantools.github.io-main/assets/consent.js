/* GyanTools privacy choices
 * Optional analytics and advertising are not loaded until the visitor chooses "Accept all".
 * This is a lightweight preference UI, not a legal guarantee or a certified CMP.
 */
(function () {
  "use strict";
  var KEY = "gyantools-optional-consent-v1";
  var choice = "";
  try { choice = localStorage.getItem(KEY) || ""; } catch (e) {}
  var loaded = false;

  function loadOptionalScripts() {
    if (loaded) return;
    loaded = true;
    var ga = document.createElement("script");
    ga.src = "/assets/ga.js";
    ga.defer = true;
    document.body.appendChild(ga);
    var ads = document.createElement("script");
    ads.src = "/assets/ads.js";
    ads.defer = true;
    document.body.appendChild(ads);
  }

  function saveChoice(value) {
    choice = value;
    try { localStorage.setItem(KEY, value); } catch (e) {}
    hideBanner();
    if (value === "all") {
      loadOptionalScripts();
    } else if (loaded) {
      // Reload ensures the optional third-party scripts are not re-initialized on this page.
      window.location.reload();
    }
    showSettingsButton();
  }

  var banner, settingsButton;
  function hideBanner() {
    if (banner) banner.hidden = true;
  }
  function showBanner() {
    if (banner) { banner.hidden = false; return; }
    banner = document.createElement("section");
    banner.setAttribute("role", "dialog");
    banner.setAttribute("aria-label", "गोपनीयता विकल्प");
    banner.setAttribute("aria-live", "polite");
    banner.innerHTML =
      '<div class="gt-consent-copy"><strong>आपकी गोपनीयता आपके हाथ में</strong>' +
      '<p>ज़रूरी site features हमेशा चालू रहते हैं। Analytics और विज्ञापन जैसे optional scripts केवल आपकी अनुमति के बाद लोड होंगे। <a href="/privacy-policy.html">Privacy Policy</a></p></div>' +
      '<div class="gt-consent-actions"><button type="button" data-choice="all">सभी स्वीकार करें</button>' +
      '<button type="button" data-choice="essential">केवल ज़रूरी</button></div>';
    banner.style.cssText = "position:fixed;z-index:2147483000;left:12px;right:12px;bottom:12px;max-width:900px;margin:auto;background:#fff;color:#202124;border:1px solid #dadce0;border-radius:14px;box-shadow:0 8px 32px rgba(0,0,0,.22);padding:16px;display:flex;gap:16px;align-items:center;justify-content:space-between;font:14px/1.5 system-ui,-apple-system,sans-serif";
    var style = document.createElement("style");
    style.textContent = ".gt-consent-copy{flex:1;min-width:180px}.gt-consent-copy p{margin:5px 0 0}.gt-consent-copy a{color:#1a73e8}.gt-consent-actions{display:flex;gap:8px;flex-wrap:wrap}.gt-consent-actions button,.gt-privacy-settings{border:0;border-radius:8px;padding:10px 13px;font:600 14px system-ui;cursor:pointer}.gt-consent-actions button[data-choice=all]{background:#1a73e8;color:#fff}.gt-consent-actions button[data-choice=essential]{background:#f1f3f4;color:#202124}.gt-privacy-settings{position:fixed;z-index:2147482000;right:12px;bottom:12px;background:#fff;color:#202124;border:1px solid #dadce0;box-shadow:0 2px 8px #0002}.gt-consent-actions button:focus-visible,.gt-privacy-settings:focus-visible{outline:3px solid #fbbc04;outline-offset:2px}@media(max-width:600px){#gt-consent-banner{display:block!important} .gt-consent-actions{margin-top:12px}.gt-consent-actions button{flex:1}}";
    style.id = "gt-consent-style";
    document.head.appendChild(style);
    banner.id = "gt-consent-banner";
    banner.addEventListener("click", function (event) {
      var button = event.target.closest("button[data-choice]");
      if (button) saveChoice(button.getAttribute("data-choice"));
    });
    document.body.appendChild(banner);
  }

  function showSettingsButton() {
    if (settingsButton) return;
    settingsButton = document.createElement("button");
    settingsButton.type = "button";
    settingsButton.className = "gt-privacy-settings";
    settingsButton.textContent = "Privacy choices";
    settingsButton.setAttribute("aria-label", "गोपनीयता विकल्प बदलें");
    settingsButton.addEventListener("click", showBanner);
    document.body.appendChild(settingsButton);
  }

  if (choice === "all") {
    loadOptionalScripts();
    showSettingsButton();
  } else {
    showBanner();
    if (choice === "essential") showSettingsButton();
  }
})();