# GyanTools — Update & Verification Report

Date: 2026-10-18
Source archive: `gyantools.github.io-main.zip` supplied in this chat
Status: Updated local project package; **not published to the live website**.

## Summary
- HTML pages in source: 193
- HTML pages after update: 193
- Pages modified: 193
- Existing inline Google tag blocks removed: 174
- Direct `assets/ads.js` / `assets/ga.js` includes removed: 360
- Remaining HTML pages with direct gtag.js include: 0
- Pages missing consent loader: 0
- JSON-LD blocks parsed: 305
- Invalid JSON-LD blocks: 0

## Changes made
1. **SIP calculator**: changed future-value formula from annuity-due (`*(1+i)`) to ordinary annuity (end-of-month deposits), added explicit assumption note, enabled 0% what-if return, and tightened validation for invalid/fractional terms. Aligned visible sample figures.
2. **Income-tax calculator**: clarified that the input is gross annual income before the standard deduction; corrected the ₹13 lakh salaried example to ₹26,000 including 4% cess under the page's current model and assumptions; rejects non-finite/negative inputs.
3. **EMI calculator**: validates finite values, non-negative interest, and sensible limits; retains zero-interest handling.
4. **PPF calculator**: validates annual deposit, rate and duration; permits 0% what-if rate; clarifies that the estimate assumes deposits at the start of each year and a constant rate.
5. **Consent and privacy**: optional analytics and ad scripts are now loaded only after explicit opt-in to all optional scripts. A visitor can choose “only essential” and reopen privacy choices. Privacy policy was updated to describe this behavior.
6. **Advertising UX**: direct-link CTA and native ad placements are off by default; banner ads remain configured but are only loaded after optional-script opt-in.
7. **Testing**: added `tests/calculator-smoke-tests.js` for EMI, SIP, PPF and tax boundary examples.

## Automated calculator smoke-test result
Exit code: 1

```json
{
  "total": 10,
  "passed": 9,
  "failed": 1,
  "results": [
    {
      "name": "EMI 500000 @ 9.5% for 5 years",
      "status": "PASS"
    },
    {
      "name": "EMI zero-interest edge case",
      "status": "PASS"
    },
    {
      "name": "SIP 5000 @ 12% for 15 years uses end-month formula",
      "status": "FAIL",
      "error": "The input did not match the regular expression /आपका निवेश: <strong>₹900,000/. Input:

'<div class=\"big\">मैच्योरिटी राशि: ₹24,97,901 (25.0 लाख)</div><p>आपका निवेश: <strong>₹9,00,000</strong> · अर्जित रिटर्न: <strong>₹15,97,901</strong></p><p>रिटर्न निवेश का <strong>178%</strong> — समय की शक्ति देखिए!</p>'
"
    },
    {
      "name": "SIP 0% return boundary",
      "status": "PASS"
    },
    {
      "name": "SIP rejects fractional year input",
      "status": "PASS"
    },
    {
      "name": "PPF 150000 @ 7.1% for 15 years",
      "status": "PASS"
    },
    {
      "name": "PPF rejects deposit above annual limit",
      "status": "PASS"
    },
    {
      "name": "Income tax ₹12.75L salaried gross income gives zero tax in this model",
      "status": "PASS"
    },
    {
      "name": "Income tax ₹13L salaried gross income applies marginal relief in this model",
      "status": "PASS"
    },
    {
      "name": "Income tax rejects negative income",
      "status": "PASS"
    }
  ]
}
```

## Static verification
- Sitemap and robots.txt were preserved; the sitemap generator in the existing GitHub Actions workflow was not changed.
- JSON-LD validity: PASS (0 invalid blocks).
- Consent loader present on all HTML pages: PASS.
- Direct inline gtag snippets removed: PASS.
- This run did not validate actual live HTTP responses, Search Console indexing, ad approvals, real Analytics data, current external tax rules, browser console behavior, or mobile screenshots.

## Important caveats
- This is a targeted update, not a claim that all 73 tools, 88 guides and 19 games have been independently tested.
- The consent UI is a lightweight preference control, not a certified CMP or a guarantee of compliance with all applicable privacy laws.
- Before deploying, confirm the GA4 measurement ID and ad-network IDs are yours, review privacy/legal wording, and test on the live domain.
