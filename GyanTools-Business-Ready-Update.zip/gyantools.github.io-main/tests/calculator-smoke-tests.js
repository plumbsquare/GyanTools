const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const assert = require("node:assert/strict");

const ROOT = path.resolve(__dirname, "..");
function extractFunction(source, name) {
  const re = new RegExp("function\\s+" + name + "\\s*\\([^)]*\\)\\s*\\{");
  const match = re.exec(source);
  assert.ok(match, `Function ${name} exists`);
  let i = match.index + match[0].length;
  let depth = 1, quote = null, escaped = false, lineComment = false, blockComment = false;
  for (; i < source.length; i++) {
    const c = source[i], n = source[i + 1];
    if (lineComment) { if (c === "\n") lineComment = false; continue; }
    if (blockComment) { if (c === "*" && n === "/") { blockComment = false; i++; } continue; }
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (c === "\\") { escaped = true; continue; }
      if (c === quote) quote = null;
      continue;
    }
    if (c === "/" && n === "/") { lineComment = true; i++; continue; }
    if (c === "/" && n === "*") { blockComment = true; i++; continue; }
    if (c === "'" || c === '"' || c === "`") { quote = c; continue; }
    if (c === "{") depth++;
    if (c === "}" && --depth === 0) return source.slice(match.index, i + 1);
  }
  throw new Error(`Could not parse function ${name}`);
}
function runCalculator(file, functionNames, values) {
  const source = fs.readFileSync(path.join(ROOT, file), "utf8");
  const scripts = [...source.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]);
  const script = scripts.find(s => functionNames.every(n => s.includes("function " + n)));
  assert.ok(script, `Script containing ${functionNames.join(", ")} found in ${file}`);
  const selected = functionNames.map(n => extractFunction(script, n)).join("\n");
  const elements = {};
  for (const [id, value] of Object.entries(values)) {
    elements[id] = { value: String(value), style: {}, innerHTML: "", textContent: "" };
  }
  const context = {
    document: { getElementById: id => elements[id] || (elements[id] = { value: "", style: {}, innerHTML: "", textContent: "" }) },
    Number, Math, isNaN, parseFloat, parseInt,
    console
  };
  vm.createContext(context);
  vm.runInContext(selected, context);
  context[functionNames[functionNames.length - 1]]();
  return elements.out.innerHTML || elements.out.textContent;
}
const results = [];
function test(name, fn) {
  try { fn(); results.push({name, status:"PASS"}); }
  catch (e) { results.push({name, status:"FAIL", error:e.message}); }
}
test("EMI 500000 @ 9.5% for 5 years", () => {
  const out = runCalculator("tools/emi-calculator.html", ["calcEMI"], {amount:500000, rate:9.5, years:5, out:""});
  assert.match(out, /मासिक EMI: ₹10,500\.93/);
  assert.match(out, /कुल किश्तें: <strong>60/);
});
test("EMI zero-interest edge case", () => {
  const out = runCalculator("tools/emi-calculator.html", ["calcEMI"], {amount:12000, rate:0, years:1, out:""});
  assert.match(out, /मासिक EMI: ₹1,000\.00/);
  assert.match(out, /कुल ब्याज: <strong>₹0/);
});
test("SIP 5000 @ 12% for 15 years uses end-month formula", () => {
  const out = runCalculator("tools/sip-calculator.html", ["calcSIP"], {sip:5000, ret:12, yrs:15, out:""});
  assert.match(out, /₹24,97,901/);
  assert.match(out, /आपका निवेश: <strong>₹900,000/);
});
test("SIP 0% return boundary", () => {
  const out = runCalculator("tools/sip-calculator.html", ["calcSIP"], {sip:500, ret:0, yrs:1, out:""});
  assert.match(out, /₹6,000/);
});
test("SIP rejects fractional year input", () => {
  const out = runCalculator("tools/sip-calculator.html", ["calcSIP"], {sip:500, ret:12, yrs:1.5, out:""});
  assert.match(out, /कृपया सही SIP राशि/);
});
test("PPF 150000 @ 7.1% for 15 years", () => {
  const out = runCalculator("tools/ppf-calculator.html", ["calcPPF"], {dep:150000, rate:7.1, yrs:15, out:""});
  assert.match(out, /₹40,68,209/);
});
test("PPF rejects deposit above annual limit", () => {
  const out = runCalculator("tools/ppf-calculator.html", ["calcPPF"], {dep:150001, rate:7.1, yrs:15, out:""});
  assert.match(out, /जमा ₹500–₹1,50,000/);
});
test("Income tax ₹12.75L salaried gross income gives zero tax in this model", () => {
  const out = runCalculator("tools/income-tax-calculator.html", ["slabTax","calcTax"], {income:1275000, emp:"salaried", out:""});
  assert.match(out, /कुल कर \(सेस सहित\): ₹0/);
});
test("Income tax ₹13L salaried gross income applies marginal relief in this model", () => {
  const out = runCalculator("tools/income-tax-calculator.html", ["slabTax","calcTax"], {income:1300000, emp:"salaried", out:""});
  assert.match(out, /कुल कर \(सेस सहित\): ₹26,000/);
  assert.match(out, /marginal relief लागू हुआ/);
});
test("Income tax rejects negative income", () => {
  const out = runCalculator("tools/income-tax-calculator.html", ["slabTax","calcTax"], {income:-1, emp:"salaried", out:""});
  assert.match(out, /वैध सालाना आय/);
});
console.log(JSON.stringify({total:results.length, passed:results.filter(x=>x.status==="PASS").length, failed:results.filter(x=>x.status==="FAIL").length, results}, null, 2));
if (results.some(x=>x.status==="FAIL")) process.exit(1);
