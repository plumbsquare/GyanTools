# GyanTools — Business-readiness update

This package is an updated copy of the supplied public-site source. It has **not** been published to GitHub Pages.

## Main changes
- Corrected SIP future-value calculation to use the standard end-of-month contribution assumption and aligned the displayed examples.
- Hardened EMI, SIP, PPF and income-tax input validation.
- Corrected the ₹13 lakh salaried income example to match the calculator's existing slab/marginal-relief model (₹26,000 including 4% cess under the page's stated assumptions; surcharge and special income treatment excluded).
- Added a consent-first loader: analytics and advertising scripts are not loaded until the visitor opts in to all optional scripts.
- Disabled direct-link CTA and native ads by default; retained only banner ads after optional-script consent.
- Updated privacy policy to describe the current scripts and consent behavior.
- Added a Node.js smoke-test harness for key calculator cases.

## Run tests
Requires Node.js 18+:
```bash
node tests/calculator-smoke-tests.js
```

## Deploy safely
1. Review the changes and run the tests.
2. Check that the Google Analytics property ID and Adsterra configuration are yours and active.
3. Check current applicable privacy/consent requirements for your actual audience and advertising providers. The included consent UI is a lightweight preference control, not a certified consent-management platform and not a guarantee of legal compliance.
4. Upload the **contents** of this folder to your repository's deployment branch using your usual reviewed deployment process. Do not upload the outer ZIP as a replacement for the repository unless your existing workflow is intended to deploy ZIP files.
5. After publishing, verify live pages, `sitemap.xml`, `robots.txt`, calculator outputs, analytics opt-in, ad opt-in and the Search Console property.

## Important limitations
- This is not a complete line-by-line audit of every page or tool.
- No live browser, device matrix, Search Console, Analytics or ad-network dashboard access was used to validate this package.
- Financial calculator logic is tested against the assumptions written on the page, not a substitute for official tax/accounting advice.
